
-------------------------------------------------------------

ITU-T Rec. T.87(06/1998)|ISO/IEC 14495-1:1999
         
-------------------------------------------------------------

1.	Content
--------------

jlsrefV100.zip - JPEG-LS reference implementation
jlsimgV100.zip - JPEG-LS comformance testing image set.
jlsauxV100.zip - Auxiliary programs and examples - NOT PART OF 
                 (ITU-T Rec. T.87|ISO/IEC 14495-1).
LEGAL          - Legal/copyright notice.
Readme.txt     - The file you are reading

2.	Support:
---------------
For distribution of update software, please contact:
Sales Department
ITU
Place des Nations
CH-1211 Geneve 20
SUISSE
email: sales@itu.int

For reporting problems, please contact TSB helpdesk service at:
TSB Helpdesk service
ITU
Place des Nations
CH-1211 Geneve 20
SUISSE
fax: +41 22 730 5853
email: tsbedh@itu.int

